<?php $this->load->view('includes/header');?>
<body class="off-canvas hide-extras">
<section class="main">
	<?php $this->load->view('navigation');?>
	<div class="container">
		badges area
	</div>	
</section>
<?php $this->load->view('includes/footer');?>