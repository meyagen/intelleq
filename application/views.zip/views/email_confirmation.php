<h1>Waiting for Email Confirmation</h1>
<p>You're one step away from creating your account! Please check your email for instructions on how to activate your account. :) 
<?php echo anchor(' ','Take me back!') ?></p>