<body style="margin-top:65px">
  <div class="row">
    <div class="large-6 push-3 columns">
      <center><i class="icon-flag-checkered white" style="font-size:100px"></i></center>
      <center><h2 class="white">Congratulations!</h2><h3 class="white">You have successfully activated your account.</h3></center>
      <div class="pic" id="signUpSuccess" style="padding-top:20px;padding-bottom:20px;"></div>
        <a class="button radius success expand large" style="padding-left:20px;padding-right:20px" href="<?php echo site_url(''); ?>"><div class="row">
          <div class="large-4 columns"><div class="panel expand" style="width:100%;height:138px;margin-bottom:0px;background-color:rgba(256,256,256,0);background-image: url('<?php echo site_url('img/biglogo.png'); ?>');
    background-position: center center;
    background-size:contain;
    background-repeat: no-repeat;"></div></div><div class="large-8 columns">
            <h2 class="white" style="margin:0px;line-height:100%">
              Start using <br class="hide-for-small"/>intelleq now!
            </h2>
          </div>
        </div>
      </a>
    </div>
  </div>
