<?php $this->load->view('components/profile_head'); ?>

<?php 
	$this->load->view($main_content); 
?>

<?php $this->load->view('components/profile_tail');?>