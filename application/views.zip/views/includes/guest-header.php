<!--Navigation Bar-->
<header>
<div class="fixed">
<nav class="top-bar fixed">
  <ul class="title-area" style="display:inline">
    <li class="toggle-topbar menu-icon right" style="padding-top:22px"><a href="#"><span></span></a></li>
    <li class="name"><a href="<?php echo base_url(); ?>" class="icon"> </a><h1><a href="<?php echo base_url(); ?>" style="display:inline">intelleq</a></h1></li>
    
  </ul>
  <section class="top-bar-section">
    <ul class="right"style="background:rgba(105, 34, 34, 0)">
      <li style="padding-right:10;padding-left:10"><a class="button trans radius" href="#" data-reveal-id="modalSignIn">Sign In</a></li>
      <li style="padding-right:10;padding-left:10"><a class="button radius trans_success" href="#" data-reveal-id="modalSignUp">Sign Up</a></li>
      <fb:login-button show-faces="true" width="200" max-rows="1"></fb:login-button>
    </ul>
  </section>
</div>
</header>