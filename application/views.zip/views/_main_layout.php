<?php $this->load->view('components/page_head'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('components/page_tail'); ?>