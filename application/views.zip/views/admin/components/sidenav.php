  <div class="large-3 columns">
    <div class="row fullrow">
    <div class="large-10 push-1 columns">
        <div class="panel">
    <h4>Navigation</h4>
    <div class="docs section-container accordion" data-section="accordion">
        <!-- <section class="section">
    <p class="title"><a href="">Feed</a></p>
  </section>
  <section class="section ">
    <p class="title"><a href="#">Calendar</a></p>
  </section> 
  <section class="section active" style="background:#efefef">
    <p class="title" style="background:#efefef"><a>Modules</a></p>
    <div class="content"> 
      <ul class="side-nav">
        <li><a href="question">Edit questions</a></li>
        <li><a href="reviewer">Edit reviewers</a></li>
        <li><a href="#"><del>Edit links</del></a></li>
      </ul>
    </div>
  </section>-->
  <section class="section">
    <p class="title"><a href="question">Questions</a></p>
  </section>
  <section class="section">
    <p class="title"><a href="reviewer">Reviewers</a></p>
  </section>
  <section class="section ">
    <p class="title"><a href="user">Users</a></p>
  </section>
  <!-- <section class="section ">
    <p class="title"><a href="#">Records</a></p>
  </section>
  <section class="section ">
    <p class="title"><a href="#">Statistics</a></p>
  </section>
  <section class="section ">
    <p class="title"><a href="#">Badges</a></p>
  </section> -->
</div>
</div>
</div>
</div>
  </div>