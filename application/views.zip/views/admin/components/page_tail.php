  <script type="text/javascript" src="<?php echo site_url('js/admin-validation.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.alerts.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.clearing.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.cookie.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.dropdown.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.forms.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.joyride.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.magellan.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.orbit.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.placeholder.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.reveal.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.section.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.tooltips.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.topbar.js'); ?>"></script>
  <script src="<?php echo site_url('js/foundation/foundation.interchange.js'); ?>"></script>
  <script>
    $(document).foundation();
</script>

</body>
</html>