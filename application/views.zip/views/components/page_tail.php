<script>document.write('<script src=' +
  ('__proto__' in {} ? 'js/vendor/custom.zepto' : 'js/vendor/custom.jquery') +
  '.js><\/script>')</script>
  <!--script type="text/javascript" src="<?php echo site_url('js/vendor/custom.zepto.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/vendor/custom.jquery.js'); ?>"></script-->
  <script type="text/javascript" src="<?php echo site_url('js/guest-validation.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.alerts.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.clearing.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.cookie.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.dropdown.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.forms.js'); ?>"></script>
  <!--script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.joyride.js'); ?>"></script-->
  <!--script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.magellan.js'); ?>"></script-->
  <!--script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.orbit.js'); ?>"></script-->
  <!--script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.placeholder.js'); ?>"></script-->
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.reveal.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.section.js'); ?>"></script>
  <!--script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.tooltips.js'); ?>"></script-->
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.topbar.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo site_url('js/foundation/foundation.interchange.js'); ?>"></script>
  <script>
    $(document).foundation();
    </script>
</body>
</html>