<!-- Reveal Modals end -->

    <script>
  document.write('<script src=' +
  ('__proto__' in {} ? 'js/vendor/custom.zepto' : 'js/vendor/custom.jquery') +
  '.js><\/script>')
  </script>
   
    <script src="js/docs.js"></script>

  <script src="js/foundation/foundation.alerts.js"></script>
  <script src="js/foundation/foundation.clearing.js"></script>
  <script src="js/foundation/foundation.cookie.js"></script>
  <script src="js/foundation/foundation.dropdown.js"></script>
  <script src="js/foundation/foundation.forms.js"></script>
  <script src="js/foundation/foundation.joyride.js"></script>
  <script src="js/foundation/foundation.magellan.js"></script>
  <!--script src="js/foundation/foundation.orbit.js"></script-->
  <script src="js/foundation/foundation.placeholder.js"></script>
  <script src="js/foundation/foundation.reveal.js"></script>
  <!--script src="js/foundation/foundation.tooltips.js"></script-->
  <script src="js/foundation/foundation.topbar.js"></script>
  <script src="js/foundation/foundation.interchange.js"></script>
  <script>
    $(document).foundation();
</script>

</body>
</html>