<body style="margin-top:65px">
  <div class="row">
    <div class="large-6 push-3 columns">
      <center><i class="icon-ambulance white" style="font-size:100px"></i></center>
      <center><h2 class="white">Invalid!</h2><h3 class="white">Unfortunately, we were unable to confirm your e-mail address. Please try again.</h3></center>
      <div class="pic" id="signUpSuccess" style="padding-top:20px;padding-bottom:20px;"></div>
        <a class="button radius success expand large" style="padding-left:20px;padding-right:20px" href="<?php echo site_url(''); ?>"><div class="row">
          <div class="large-3 columns"><div class="panel expand" style="width:100%;height:92px;margin-bottom:0px;background-color:rgba(256,256,256,0);background-image: url('<?php echo site_url('img/biglogo.png'); ?>');
    background-position: center center;
    background-size:contain;
    background-repeat: no-repeat;"></div></div>
    	  <div class="large-9 columns" style="padding-top:28px">
            <h3 class="white" style="margin:0px;line-height:100%">
              Go to intelleq
            </h3>
          </div>
        </div>
      </a>
    </div>
  </div>
