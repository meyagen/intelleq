<?php $this->load->view('components/page_head'); ?>
<body class="off-canvas hide-extras">
	<?php $this->load->view('includes/header');?>
	<section class="main">
		<?php $this->load->view('navigation'); ?>
		<div>
			Imagine a calendar here.
		</div>	
	</section>

<?php $this->load->view('includes/footer');?>